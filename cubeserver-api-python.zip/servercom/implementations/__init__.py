"""The Implementations of the Python API Wrapper

These are separate implementations of the API wrapper which generally serve
the same purpose, but are meant to run on different hardware or to be used
in different situations.
"""
