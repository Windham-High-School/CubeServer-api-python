# This file is run on hard resets and during code updates.
import storage
from microcontroller import nvm

remount = int(nvm[1]) == 0xff
nvm[1] = 0x00

if remount:
        write_mode = int(nvm[0]) == 0xff
        read_mode  = int(nvm[0]) == 0xee

        if write_mode:
                print("Disabling USB drive")
                storage.disable_usb_drive()
                storage.remount("/", False)

        if read_mode:
                print("Enabling USB drive")
                storage.enable_usb_drive()
                storage.remount("/", True)
